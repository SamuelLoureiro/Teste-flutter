import 'package:flutter/material.dart';
import './questionario.dart';
import './resultado.dart';

void main() => runApp(const PerguntaApp());

class _PerguntaAppState extends State<PerguntaApp> {
  var _perguntaSelecionada = 0;
  var _pontuacaoTotal = 0;
  final _perguntas = const [
    {
      'texto': 'Quem ganhou a copa de 1958?',
      'respostas': [
        {'texto': 'Brasil', 'pontuacao': 10},
        {'texto': 'Suecia', 'pontuacao': 5},
        {'texto': 'Argentina', 'pontuacao': 3},
        {'texto': 'Inglaterra', 'pontuacao': 1},
      ],
    },
    {
      'texto': 'Em que ano o Real Madrid conquistou sua 14 Champions League?',
      'respostas': [
        {'texto': '2019/2020', 'pontuacao': 1},
        {'texto': '2022/2023', 'pontuacao': 5},
        {'texto': '2018/2019', 'pontuacao': 3},
        {'texto': '2021/2022', 'pontuacao': 10},
      ],
    },
    {
      'texto': 'Quantas bolas de ouro Ronaldinho tem?',
      'respostas': [
        {'texto': '0', 'pontuacao': 3},
        {'texto': '1', 'pontuacao': 5},
        {'texto': '2', 'pontuacao': 10},
        {'texto': '5', 'pontuacao': 1},
      ],
    }
  ];

  void _responder(int pontuacao) {
    if (temPerguntaSelecionada) {
      setState(() {
        _perguntaSelecionada++;
        _pontuacaoTotal += pontuacao;
      });
    }
  }

  void _reiniciarQuestionario() {
    setState(() {
      _perguntaSelecionada = 0;
      _pontuacaoTotal = 0;
    });
  }

  bool get temPerguntaSelecionada {
    return _perguntaSelecionada < _perguntas.length;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Perguntas'),
        ),
        body: temPerguntaSelecionada
            ? Questionario(
                perguntas: _perguntas,
                perguntaSelecionada: _perguntaSelecionada,
                quandoResponder: _responder,
              )
            : Resultado(_pontuacaoTotal, _reiniciarQuestionario),
      ),
    );
  }
}

class PerguntaApp extends StatefulWidget {
  const PerguntaApp({super.key});

  @override
  _PerguntaAppState createState() {
    return _PerguntaAppState();
  }
}
